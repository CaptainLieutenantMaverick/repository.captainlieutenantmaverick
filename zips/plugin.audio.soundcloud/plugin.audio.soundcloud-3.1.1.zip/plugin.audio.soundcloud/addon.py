from resources import plugin

plugin.run()

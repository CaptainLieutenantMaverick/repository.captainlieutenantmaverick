# -*- coding: utf-8 -*-


# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)


import os           
import xbmc        
import xbmcaddon 
import xbmcplugin   
import re     
import xbmcgui      

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File



debug        = Addon_Setting(setting='debug')    
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 


BASE  = "plugin://plugin.video.youtube/playlist/"

YOUTUBE_CHANNEL_ID_1 = "PLZc2vaaVVzP6n3t43b_A1vr35-zQplqAv"
YOUTUBE_CHANNEL_ID_2 = "PLZc2vaaVVzP7v63KCouhu57j0OUkVFPkG"
YOUTUBE_CHANNEL_ID_3 = "PLZc2vaaVVzP7by4jiE0PFDf2e7rPfsQgU"
YOUTUBE_CHANNEL_ID_4 = "PLZc2vaaVVzP48iUrHAi0-v9XcigBsHByo"
YOUTUBE_CHANNEL_ID_5 = "PLZc2vaaVVzP5IuAow3R-Aix4-HgYLuObJ"
YOUTUBE_CHANNEL_ID_6 = "PLZc2vaaVVzP6yq2soN5H2z3gDAMS9Tt0K"
YOUTUBE_CHANNEL_ID_7 = "PLZc2vaaVVzP5yHoL9ufWAJNbCJRUV0jdx"
YOUTUBE_CHANNEL_ID_8 = "PLZc2vaaVVzP5jhV8CWhIoZ84L3notsohR"
YOUTUBE_CHANNEL_ID_9 = "PLZc2vaaVVzP4E-ROZYwhucTi6WIdPjf3M"
YOUTUBE_CHANNEL_ID_10 = "PLZc2vaaVVzP52rquJeCnSQnW5IMOE0zOo"
YOUTUBE_CHANNEL_ID_11 = "PLZc2vaaVVzP4G8KQoyq8lMwN2quvVSGwT"


@route(mode='main_menu')
def Main_Menu():
	Add_Dir( 
        name="Workout's for men", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="http://grindhousekodi.tk/grindhouse/images/fitness/icon.png")
		
	Add_Dir( 
        name="Women's workouts", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/fitness/icon.png")
	
	Add_Dir( 
        name="Motivation & insperation", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
        icon="http://grindhousekodi.tk/grindhouse/images/fitness/icon.png")

	Add_Dir( 
		name="Slimming world",url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/fitness/icon.png")
	
	Add_Dir( 
        name="Self defence", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
        icon="http://grindhousekodi.tk/grindhouse/images/fitness/icon.png")
	
	Add_Dir( 
        name="Fun workouts", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
        icon="http://grindhousekodi.tk/grindhouse/images/fitness/icon.png")
	
	Add_Dir( 
        name="Keto/paleo/lowcarb", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
        icon="http://grindhousekodi.tk/grindhouse/images/fitness/icon.png")
		
	Add_Dir( 
        name="Weight watchers", url=BASE+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
        icon="http://grindhousekodi.tk/grindhouse/images/fitness/icon.png")
		
	Add_Dir( 
        name="Macro's & calorie counting", url=BASE+YOUTUBE_CHANNEL_ID_9+"/", folder=True,
        icon="http://grindhousekodi.tk/grindhouse/images/fitness/icon.png")
		
	Add_Dir( 
        name="Myfitnesspal", url=BASE+YOUTUBE_CHANNEL_ID_10+"/", folder=True,
        icon="http://grindhousekodi.tk/grindhouse/images/fitness/icon.png")
		
	Add_Dir( 
        name="Random diets & info", url=BASE+YOUTUBE_CHANNEL_ID_11+"/", folder=True,
        icon="http://grindhousekodi.tk/grindhouse/images/fitness/icon.png")
		
	
		
		
@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()

@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)

if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
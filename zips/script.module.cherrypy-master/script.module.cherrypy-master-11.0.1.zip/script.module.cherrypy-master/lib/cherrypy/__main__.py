from cherrypy.daemon import run


if __name__ == '__main__':
    run()

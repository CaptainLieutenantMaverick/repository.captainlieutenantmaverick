# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)


import os           
import xbmc         
import xbmcaddon    
import xbmcplugin   

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File



debug        = Addon_Setting(setting='debug')       
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

BASE  = "plugin://plugin.video.youtube/playlist/"


YOUTUBE_CHANNEL_ID_1 = "PLqrLEr7tAISqaGLNuycQwq2paRnTmpiql"
YOUTUBE_CHANNEL_ID_2 = "PLqrLEr7tAISpGN601RNGAIki1Cu037H51"
YOUTUBE_CHANNEL_ID_3 = "PLqrLEr7tAISo2Ti4KPOA-2d0_qy0J-XE6"
YOUTUBE_CHANNEL_ID_4 = "PLqrLEr7tAISoVT9Xp8SGM0Juj02JL--LO"
YOUTUBE_CHANNEL_ID_5 = "PLqrLEr7tAISorvcENcRu4N2LxUWd7v9zk"
YOUTUBE_CHANNEL_ID_6 = "PLqrLEr7tAISq_ErrAfDCglXRq4K6Ygl-n"
YOUTUBE_CHANNEL_ID_7 = "PLqrLEr7tAISr9XI4GBu7RVSZcVNiDEcge"
YOUTUBE_CHANNEL_ID_8 = "PLqrLEr7tAISrtI5hC_QZu8LzGi_gW4ilZ"
YOUTUBE_CHANNEL_ID_9 = "PLqrLEr7tAISojK6XXsoc7SuQgMZV6bg1i"
YOUTUBE_CHANNEL_ID_10 = "PLqrLEr7tAISp3X8OUW8eO_qk2KKxNl5Ba"



@route(mode='main_menu')
def Main_Menu():




	Add_Dir( 
		name="Comedy", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/otr.png")
		
	Add_Dir( 
		name="Holidays", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/otr.png")
		
	Add_Dir( 
		name="Horror", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/otr.png")
		
	Add_Dir( 
		name="Kids", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/otr.png")
		
	Add_Dir( 
		name="Mystery, drama, and suspense", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/otr.png")
		
	Add_Dir( 
		name="Sci-fi", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/otr.png")
		
	Add_Dir( 
		name="Superheros", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/otr.png")
		
	Add_Dir( 
		name="TV shows", url=BASE+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/otr.png")
		
	Add_Dir( 
		name="Variety", url=BASE+YOUTUBE_CHANNEL_ID_9+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/otr.png")
		
	Add_Dir( 
		name="Westerns", url=BASE+YOUTUBE_CHANNEL_ID_10+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/otr.png")





#----------------------------------------------------------------
# A basic OK Dialog
@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()
#----------------------------------------------------------------
# A basic OK Dialog
@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)


if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))